

import UIKit
import AVFoundation
import AVKit

class ThirdViewController: UIViewController {

    
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var backBTN: UIButton!
    
    @IBOutlet weak var codeBTN: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true

        guard let path = Bundle.main.path(forResource: "bubble", ofType:"mov") else {
            debugPrint("video.m4v not found")
            return
        }
        let player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = videoView.bounds
        videoView.layer.addSublayer(playerLayer)
        player.play()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func backBTN_Pressed(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBAction func codeBTN_Pressed(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "CONVEXWEBViewController")as! CONVEXWEBViewController
        nextVC.urlString = "https://rosettacode.org/wiki/Sorting_algorithms/Bubble_sort#Python"
        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
    

   
    

}

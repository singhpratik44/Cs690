

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var nameArray = ["CONEX HULL","BUBBLE SORT"]
    var imageArray = ["convexhull","bubbleshort"]
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
        
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "homeScreenCell", for: indexPath) as! HomeScreenCell
        
        
        cell.cellLabel.text = nameArray[indexPath.row]
        cell.cellImageView.image = UIImage(imageLiteralResourceName: imageArray[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0 {
            let nextVC = storyboard?.instantiateViewController(withIdentifier: "SecondViewController")as! SecondViewController
            self.navigationController?.pushViewController(nextVC, animated: true)
        }else {
            
            let nextVC = storyboard?.instantiateViewController(withIdentifier: "ThirdViewController")as! ThirdViewController
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.height / 2
    }
    
}




import UIKit
import WebKit

class CONVEXWEBViewController: UIViewController {
    
    var urlString = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true

        // Do any additional setup after loading the view.
        let webView = WKWebView(frame: CGRect(x: 0, y: 88, width: self.view.frame.size.width, height: self.view.frame.size.height))
        self.view.addSubview(webView)
        let url = URL(string: "\(urlString)")
        webView.load(URLRequest(url: url!))
    }
    

  
    @IBAction func backBTN_Pressed(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

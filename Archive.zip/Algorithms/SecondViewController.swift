

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var animationView: UIView!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button0: UIButton!
    @IBOutlet weak var backBTN: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isHidden = true
        
        button0.layer.borderWidth = 1
        button0.layer.borderColor = UIColor.black.cgColor
        button0.layer.cornerRadius = button0.frame.height / 2
        
        button1.layer.borderWidth = 1
        button1.layer.borderColor = UIColor.black.cgColor
        button1.layer.cornerRadius = button1.frame.height / 2
        
        
        button2.layer.borderWidth = 1
        button2.layer.borderColor = UIColor.black.cgColor
        button2.layer.cornerRadius = button2.frame.height / 2
        
        button3.layer.borderWidth = 1
        button3.layer.borderColor = UIColor.black.cgColor
        button3.layer.cornerRadius = button3.frame.height / 2

        
        Timer.scheduledTimer(timeInterval: 0.7, target: self, selector: #selector(update01), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 1.5, target: self, selector: #selector(update02), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 2.2, target: self, selector: #selector(update03), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 2.9, target: self, selector: #selector(update04), userInfo: nil, repeats: false)
        
        Timer.scheduledTimer(timeInterval: 3.5, target: self, selector: #selector(ThikUpdate01), userInfo: nil, repeats: false)
    
        
        Timer.scheduledTimer(timeInterval: 4.3, target: self, selector: #selector(whiteUpdate01), userInfo: nil, repeats: false)
         Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(orangeUpdate12), userInfo: nil, repeats: false)
        
          Timer.scheduledTimer(timeInterval: 5.7, target: self, selector: #selector(whiteUpdate12), userInfo: nil, repeats: false)
        
         Timer.scheduledTimer(timeInterval: 6.4, target: self, selector: #selector(orangeUpdate23), userInfo: nil, repeats: false)
        
         Timer.scheduledTimer(timeInterval: 7, target: self, selector: #selector(whiteUpdate23), userInfo: nil, repeats: false)
        
        // Do any additional setup after loading the view.
    }
    
    
    
  
    @IBAction func backBTN_Pressed(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func codeBTN_Pressed(_ sender: Any) {
        
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "CONVEXWEBViewController")as! CONVEXWEBViewController
        nextVC.urlString = "https://rosettacode.org/wiki/Convex_hull#Python"
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    
    func drawLineFromPoint(start : CGPoint, toPoint end:CGPoint, ofColor lineColor: UIColor, inView view:UIView) {
        
        //design the path
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
      
        
        
        //design path in layer
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = 3.0
        
        
        view.layer.addSublayer(shapeLayer)
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = 0
        animation.duration = 0.7
        shapeLayer.add(animation, forKey: "MyAnimation")
        view.layer.addSublayer(shapeLayer)
        
        
      
        
    }
    
    func drawThikLineFromPoint(start : CGPoint, toPoint end:CGPoint, ofColor lineColor: UIColor, inView view:UIView) {
        
        //design the path
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        
        
        
        //design path in layer
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = 5.0
        
        
        view.layer.addSublayer(shapeLayer)
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = 0
        animation.duration = 0.5
        shapeLayer.add(animation, forKey: "MyAnimation")
        view.layer.addSublayer(shapeLayer)
        
        
        
        
    }
    
    
    func drawBlackLineFromPoint(start : CGPoint, toPoint end:CGPoint, ofColor lineColor: UIColor, inView view:UIView) {
        
        //design the path
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        
        
        
        //design path in layer
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = 5.0
        
        
        view.layer.addSublayer(shapeLayer)
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = -1
        animation.duration = 0
        shapeLayer.add(animation, forKey: "MyAnimation")
        view.layer.addSublayer(shapeLayer)
        
        
        
        
    }
    
    
    
    @objc func update01() {
        print("1")
          drawLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.orange, inView: self.animationView)
        
        button0.layer.borderColor = UIColor.orange.cgColor
        button1.layer.borderColor = UIColor.orange.cgColor
    }
    
    @objc func update02() {
        print("2")
        drawLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 28 , y: button0.frame.origin.y + 6), toPoint: CGPoint(x: button2.frame.origin.x, y: button2.frame.origin.y + 15), ofColor: UIColor.orange, inView: self.animationView)
        
        button2.layer.borderColor = UIColor.orange.cgColor
        button1.layer.borderColor = UIColor.black.cgColor
        
        
         drawLineFromPoint(start: CGPoint(x: button1.frame.origin.x , y: button1.frame.origin.y + 10), toPoint: CGPoint(x: button0.frame.origin.x + 30, y: button0.frame.origin.y + 13), ofColor: UIColor.white, inView: self.animationView)
        
        
    }
    
    @objc func update03() {
        print("3")
        drawLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 12 , y: button0.frame.origin.y), toPoint: CGPoint(x: button3.frame.origin.x + 15, y: button3.frame.origin.y + 30), ofColor: UIColor.orange, inView: self.animationView)
        
         button3.layer.borderColor = UIColor.orange.cgColor
        button2.layer.borderColor = UIColor.black.cgColor
        
        drawLineFromPoint(start: CGPoint(x: button2.frame.origin.x, y: button2.frame.origin.y + 15), toPoint: CGPoint(x: button0.frame.origin.x + 28 , y: button0.frame.origin.y + 6), ofColor: UIColor.white, inView: self.animationView)

        
    }
    
    @objc func update04() {
        
         button0.layer.borderColor = UIColor.black.cgColor
        button1.layer.borderColor = UIColor.black.cgColor
        button2.layer.borderColor = UIColor.black.cgColor
        button3.layer.borderColor = UIColor.black.cgColor
        
         drawLineFromPoint(start: CGPoint(x: button3.frame.origin.x + 15, y: button3.frame.origin.y + 30), toPoint: CGPoint(x: button0.frame.origin.x + 12  , y: button0.frame.origin.y), ofColor: UIColor.white, inView: self.animationView)
    }
    
    @objc func ThikUpdate01() {
        button3.backgroundColor = UIColor.orange
        button3.layer.borderColor = UIColor.orange.cgColor
        
        drawThikLineFromPoint(start: CGPoint(x: button3.frame.origin.x + 15, y: button3.frame.origin.y + 30), toPoint: CGPoint(x: button0.frame.origin.x + 12  , y: button0.frame.origin.y), ofColor: UIColor.orange, inView: self.animationView)
        
        
        button1.backgroundColor = UIColor.orange
        button1.layer.borderColor = UIColor.orange.cgColor
        
        button0.backgroundColor = UIColor.orange
        button0.layer.borderColor = UIColor.orange.cgColor
        
        drawThikLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.orange, inView: self.animationView)
        
        
    }
    @objc func whiteUpdate01() {
        button3.backgroundColor = UIColor.orange
        button3.layer.borderColor = UIColor.orange.cgColor
        
        drawBlackLineFromPoint(start: CGPoint(x: button3.frame.origin.x + 15, y: button3.frame.origin.y + 30), toPoint: CGPoint(x: button0.frame.origin.x + 12  , y: button0.frame.origin.y), ofColor: UIColor.black, inView: self.animationView)
        
        
        button1.backgroundColor = UIColor.orange
        button1.layer.borderColor = UIColor.orange.cgColor
        
        button0.backgroundColor = UIColor.orange
        button0.layer.borderColor = UIColor.orange.cgColor
        
        drawBlackLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.black, inView: self.animationView)
        
        
    }
    @objc func orangeUpdate12() {
        button2.backgroundColor = UIColor.orange
        button2.layer.borderColor = UIColor.orange.cgColor
//
        drawThikLineFromPoint(start: CGPoint(x: button1.frame.origin.x + 15, y: button1.frame.origin.y), toPoint: CGPoint(x: button2.frame.origin.x + 15  , y: button2.frame.origin.y + 30), ofColor: UIColor.orange, inView: self.animationView)
        
//
//        button1.backgroundColor = UIColor.orange
//        button1.layer.borderColor = UIColor.orange.cgColor
//
//        button0.backgroundColor = UIColor.orange
//        button0.layer.borderColor = UIColor.orange.cgColor
//
//        drawBlackLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.black, inView: self.animationView)
        
        
    }
    
    @objc func whiteUpdate12() {
        button3.backgroundColor = UIColor.orange
        button3.layer.borderColor = UIColor.orange.cgColor
        
        drawBlackLineFromPoint(start: CGPoint(x: button1.frame.origin.x + 15, y: button1.frame.origin.y), toPoint: CGPoint(x: button2.frame.origin.x + 15  , y: button2.frame.origin.y + 30), ofColor: UIColor.black, inView: self.animationView)
        
        
//        button1.backgroundColor = UIColor.orange
//        button1.layer.borderColor = UIColor.orange.cgColor
//
//        button0.backgroundColor = UIColor.orange
//        button0.layer.borderColor = UIColor.orange.cgColor
//
//        drawBlackLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.black, inView: self.animationView)
        
        
    }
    
    @objc func orangeUpdate23() {
        //        button3.backgroundColor = UIColor.orange
        //        button3.layer.borderColor = UIColor.orange.cgColor
        //
        drawThikLineFromPoint(start: CGPoint(x: button2.frame.origin.x, y: button2.frame.origin.y + 15), toPoint: CGPoint(x: button3.frame.origin.x + 30  , y: button2.frame.origin.y + 15), ofColor: UIColor.orange, inView: self.animationView)
        
        //
        //        button1.backgroundColor = UIColor.orange
        //        button1.layer.borderColor = UIColor.orange.cgColor
        //
        //        button0.backgroundColor = UIColor.orange
        //        button0.layer.borderColor = UIColor.orange.cgColor
        //
        //        drawBlackLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.black, inView: self.animationView)
        
        
    }
    
    @objc func whiteUpdate23() {
        button3.backgroundColor = UIColor.orange
        button3.layer.borderColor = UIColor.orange.cgColor
        
        drawBlackLineFromPoint(start: CGPoint(x: button2.frame.origin.x, y: button2.frame.origin.y + 15), toPoint: CGPoint(x: button3.frame.origin.x + 30  , y: button2.frame.origin.y + 15), ofColor: UIColor.black, inView: self.animationView)
        
        
        //        button1.backgroundColor = UIColor.orange
        //        button1.layer.borderColor = UIColor.orange.cgColor
        //
        //        button0.backgroundColor = UIColor.orange
        //        button0.layer.borderColor = UIColor.orange.cgColor
        //
        //        drawBlackLineFromPoint(start: CGPoint(x: button0.frame.origin.x + 30 , y: button0.frame.origin.y + 13), toPoint: CGPoint(x: button1.frame.origin.x, y: button1.frame.origin.y + 10), ofColor: UIColor.black, inView: self.animationView)
        
        
    }
}

